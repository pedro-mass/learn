# Express - View
This example shows how to set up a simple view using the Express web framework. Similar to the previous Express app example, this listens on port `8080`