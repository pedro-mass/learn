# Node

This example shows how to setup a simple HTTP server listening on port `8080` and return `"Hello World!"`