# Node Events

This example shows how to utilize events