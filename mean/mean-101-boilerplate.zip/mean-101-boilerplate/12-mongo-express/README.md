# MongoDB - Express
This example shows how to set up a simple interactions using the MongoDB with Node - Mongoose and Express.