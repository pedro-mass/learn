var 
  express = require('express'),
  mongoose = require('mongoose'),
  app = express();

mongoose.connect('mongodb://localhost/mean');

var Beer = mongoose.model('Beer', { name: String });

// route static files
app.use(express.static(__dirname + '/public'));

// create route for beer list

// create route for beer get

app.listen(process.env.PORT || 8080);

console.log('App running on port ' + (process.env.PORT || 8080) + '...');