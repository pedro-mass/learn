# Node Streams

This example shows how to setup a simple HTTP server listening on port `8080` and stream `"Hello World!"`