# Angular - Bind
This example demonstrates the usage of ngBind.