'use strict';

/**
 * @ngdoc function
 * @name meanApp.controller: MainCtrl
 * @description
 * # MainCtrl
 * Controller of the meanApp
 */
angular.module('meanApp')
  .controller('MainCtrl', ['$scope', function($scope) {
    $scope.message = 'MEAN Bootcamp 101';


  }]);
