# Angular - Class
This example demonstrates the usage of ngClass.