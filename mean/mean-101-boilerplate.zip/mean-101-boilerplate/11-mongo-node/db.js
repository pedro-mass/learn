var 
  async = require('async'),
  mongoose = require('mongoose'),
  beers = require('./data/beers.json');

