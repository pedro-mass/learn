Some utility script.

* createdemo.sh create a Docker Machine based environment for the demo
* destroydemo.sh destroy the Docker Machine environment