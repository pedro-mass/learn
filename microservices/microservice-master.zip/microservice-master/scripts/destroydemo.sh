#!/bin/sh
docker-machine rm ms
